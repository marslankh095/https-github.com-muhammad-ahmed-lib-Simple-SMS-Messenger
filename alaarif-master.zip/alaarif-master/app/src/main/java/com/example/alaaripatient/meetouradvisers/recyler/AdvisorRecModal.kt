package com.example.alaaripatient.meetouradvisers.recyler

data class AdvisorRecModal(var imageview:Int, var experience:String,val courses:String,
val reviews:String,val served:String)
