package com.example.alaaripatient.wallet.fragment.walletrecyler

data class WalletRecModal( var amounttype:String, var date:String,var amount:String,val userType:String)
