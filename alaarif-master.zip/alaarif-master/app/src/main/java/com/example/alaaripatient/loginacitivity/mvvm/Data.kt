package com.example.alaaripatient.loginacitivity.mvvm

data class Data(
    val token: Token,
    val user: User
)