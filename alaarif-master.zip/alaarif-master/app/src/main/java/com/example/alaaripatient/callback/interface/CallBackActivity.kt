package com.example.alaaripatient.callback.`interface`

import android.app.Activity
import androidx.fragment.app.Fragment

interface CallBackActivity {
    fun callback()
}