package com.example.alaaripatient.home.fragement.recylerwebinar

data class RecylerWebinarModal(var imageview:Int,var text:String, var date:String)
