package com.example.alaaripatient.loginacitivity.mvvm

data class LoginDataClass(
    val `data`: Data,
    val isSuccess: Boolean,
    val message: String
)