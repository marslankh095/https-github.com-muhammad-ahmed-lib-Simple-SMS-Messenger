package com.example.alaaripatient.signupresponsedata

data class Token(
    val accessToken: String,
    val expiresIn: String
)