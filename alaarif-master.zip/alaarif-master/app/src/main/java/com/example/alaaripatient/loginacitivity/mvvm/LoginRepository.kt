package com.example.alaaripatient.loginacitivity.mvvm

class LoginRepository {

}