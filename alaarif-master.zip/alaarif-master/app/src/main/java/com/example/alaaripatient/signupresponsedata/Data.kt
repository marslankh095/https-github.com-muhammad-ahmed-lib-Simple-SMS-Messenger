package com.example.alaaripatient.signupresponsedata

data class Data(
    val `data`: DataX,
    val isSuccess: Boolean,
    val message: String
)