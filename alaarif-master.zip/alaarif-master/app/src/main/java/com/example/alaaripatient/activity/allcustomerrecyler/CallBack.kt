package com.example.alaaripatient.activity.allcustomerrecyler

interface CallBack {
    fun callback(position:Int, modal: CustomerData)
}