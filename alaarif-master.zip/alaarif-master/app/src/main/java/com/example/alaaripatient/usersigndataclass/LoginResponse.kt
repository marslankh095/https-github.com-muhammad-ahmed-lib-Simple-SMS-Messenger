package com.example.alaaripatient.usersigndataclass

data class LoginResponse(
    val emailAddress: String,
    val password: String
)