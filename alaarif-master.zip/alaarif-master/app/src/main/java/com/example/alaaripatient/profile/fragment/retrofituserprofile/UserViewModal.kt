package com.example.alaaripatient.profile.fragment.retrofituserprofile

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class UserViewModal:ViewModel() {

    val data:MutableLiveData<UserProfileResponse> = MutableLiveData()

    fun userprofile(){

    }
}