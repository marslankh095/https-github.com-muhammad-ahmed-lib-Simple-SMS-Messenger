package com.example.alaaripatient.callback.`interface`

import com.example.alaaripatient.home.fragement.recylerwebinar.RecylerWebinarModal

interface CallBackAdapter {
    fun callback(position:Int, modal: RecylerWebinarModal)
}