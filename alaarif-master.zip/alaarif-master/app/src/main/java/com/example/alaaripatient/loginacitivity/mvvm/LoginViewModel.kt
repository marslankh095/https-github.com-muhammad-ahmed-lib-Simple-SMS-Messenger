package com.example.alaaripatient.loginacitivity.mvvm

import androidx.lifecycle.*

class LoginViewModel : ViewModel() {
//    private val _loginResult = MutableLiveData<LoginDataClass>()
//    val loginResult: LiveData<LoginDataClass> = _loginResult
//    fun login(username: String, password: String) {
//        val modal=LoginResponse(username,password)
//        var call:Call<LoginDataClass> = clineRetrofitObject.api.login(modal)
//        call.enqueue(object :Callback<LoginDataClass>{
//            override fun onResponse(
//                call: Call<LoginDataClass>,
//                response: Response<LoginDataClass>
//            ) {
//
//            }
//
//            override fun onFailure(call: Call<LoginDataClass>, t: Throwable) {
//
//            }
//
//        })
//    }
}
