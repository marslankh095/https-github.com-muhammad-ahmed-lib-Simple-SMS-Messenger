package com.example.alaaripatient.signupresponsedata

data class DataX(
    val token: Token,
    val user: User
)