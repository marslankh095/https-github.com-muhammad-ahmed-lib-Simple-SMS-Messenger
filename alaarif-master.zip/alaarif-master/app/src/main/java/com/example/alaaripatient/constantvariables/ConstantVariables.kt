package com.example.alaaripatient.constantvariables

object ConstantVariables {

    const val BASEURL="http://13.229.62.231/api/"

}