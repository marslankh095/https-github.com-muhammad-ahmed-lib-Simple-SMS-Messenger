package com.example.alaaripatient.loginacitivity.mvvm

data class Token(
    val accessToken: String,
    val expiresIn: String
)