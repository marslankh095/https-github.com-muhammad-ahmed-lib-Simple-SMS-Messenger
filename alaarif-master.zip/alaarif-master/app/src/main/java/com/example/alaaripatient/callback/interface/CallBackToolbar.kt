package com.example.alaaripatient.callback.`interface`

import androidx.fragment.app.Fragment

interface CallBackToolbar {
    fun callBack(c:Fragment)
}