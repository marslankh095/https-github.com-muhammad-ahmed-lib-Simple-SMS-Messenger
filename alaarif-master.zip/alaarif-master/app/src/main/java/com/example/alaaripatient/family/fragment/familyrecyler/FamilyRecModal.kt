package com.example.alaaripatient.family.fragment.familyrecyler

data class FamilyRecModal(var imageview:Int, val name:String,val familyCode:String,val relationType:String)
