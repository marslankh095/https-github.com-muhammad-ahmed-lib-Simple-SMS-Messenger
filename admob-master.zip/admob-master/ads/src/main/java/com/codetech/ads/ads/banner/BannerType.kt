package com.codetech.ads.ads.banner

enum class BannerType {
    ADAPTIVE,
    MEDIUM_RECTANGLE,
    COLLAPSIBLE_TOP,
    COLLAPSIBLE_BOTTOM,
    SMALL
}