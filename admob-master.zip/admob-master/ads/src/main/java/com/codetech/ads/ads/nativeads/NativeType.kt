package com.codetech.ads.ads.nativeads

enum class NativeType {
    BANNER,
    SMALL,
    SMALL_ADJUSTED,
    LARGE,
    MEDIUM
}