package com.singlerestaurant.user.utils

interface FilterClick {
    fun onFilterClick(id: Int,type: String)
}