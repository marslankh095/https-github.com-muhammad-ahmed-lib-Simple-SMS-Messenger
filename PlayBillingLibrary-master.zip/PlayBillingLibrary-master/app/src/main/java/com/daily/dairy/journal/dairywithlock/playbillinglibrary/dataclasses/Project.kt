package com.daily.dairy.journal.dairywithlock.playbillinglibrary.dataclasses

data class Project(
    val title: String,
    val link: String
)
