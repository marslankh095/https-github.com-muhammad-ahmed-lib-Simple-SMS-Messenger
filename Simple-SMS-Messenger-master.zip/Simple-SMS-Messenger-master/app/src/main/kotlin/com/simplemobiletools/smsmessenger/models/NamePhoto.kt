package com.simplemobiletools.smsmessenger.models

data class NamePhoto(val name: String, val photoUri: String?)
