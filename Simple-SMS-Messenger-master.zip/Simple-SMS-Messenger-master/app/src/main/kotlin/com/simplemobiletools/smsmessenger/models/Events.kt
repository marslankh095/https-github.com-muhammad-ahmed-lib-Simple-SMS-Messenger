package com.simplemobiletools.smsmessenger.models

class Events {
    class RefreshMessages
}
