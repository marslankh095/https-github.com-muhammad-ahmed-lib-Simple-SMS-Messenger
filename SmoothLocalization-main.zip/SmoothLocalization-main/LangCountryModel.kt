package com.pie.whatsappstatussaver.localization

data class LangCountryModel(val id: Int, val name: String, val abr: String, val flag: Int)